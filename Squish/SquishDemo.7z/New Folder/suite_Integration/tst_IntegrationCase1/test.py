def main():
    startApplication("Q2")
    source(findFile("scripts","Y:\suite_AnalysisModule\tst_Analysis\test.py"))
    source(findFile("scripts","Y:\suite_PatientModule\tst_Patient\test.py"))
    
    
    
    
    
    