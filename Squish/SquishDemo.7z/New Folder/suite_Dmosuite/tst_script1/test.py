def main():
    loadUrl("http://www.froglogic.com")
    snooze(1)