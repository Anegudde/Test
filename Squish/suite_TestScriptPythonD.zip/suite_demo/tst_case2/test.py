
def main():
    startApplication("addressbook")
    sendEvent("QCloseEvent", waitForObject(":Address Book_MainWindow"))
