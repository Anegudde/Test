
function main(){


bva(3,19);


alphanumeric(24);


}

function bva(a,b){
    
    a=a;
    test.log(a + "lower Actual value")

    b=b;
    test.log(b + "upper Actual Value")
    
    
    c=a+1;
    test.log(c + "add lower Actual value")
    d=a-1;
    test.log(d + "sub lower Actual value")
    e=b-1;
    test.log(e + "add upper Actual value")
    f=b+1;
    test.log(f + "sub upper Actual value")
    
       
}


function alphanumeric(inputtxt)  
{  
 var letterNumber = /^[0-9a-zA-Z]+$/;  
 if((inputtxt.value.match(letterNumber)) )  
  {  
   return true;  
  }  
else  
  {   
   alert("message");   
   return false;   
  }  
  
}