function main() {
    
    startApplication("quickaddressbook");
    mouseClick(":Add_Button");
    
    //mouseClick(waitForObject(":editView.firstNameField_TextField"), 13, 14, Qt.LeftButton);
    type((":editView.textInput_TextInput"), "test");
    
    
    
    
    
    mouseClick(":Add_Button");  
    
}

