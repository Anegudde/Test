function main()
{
function cmp (a,b)
{
    var a= "raks";
    var b= "raks";
    if (a == b)
    {
     test.log(pass);   
    } 
    else
    {
        test.log(fail);
    }
}
}