
def DeleteButtonCheck():
    '''Calling the Add AddressBook function'''
    if object.exists(":AddressBook_Contact_Container"):
        value = findObject(":AddressBook_Button_Remove").enabled
        if value == 0:
            test.log("Remove button not enabled as expected since the contact is not selected")
        else:
            test.fail("Remove button enabled not as expected since the contact is not selected")
        mouseClick(waitForObject(":AddressBook_Contact_Container"))
        value = findObject(":AddressBook_Button_Remove").enabled
        if value == 1:
            test.log("Remove button  enabled as expected since the contact is  selected")
            status = "Pass"
        else:
            test.fail("Remove button not enabled as expected since the contact is  selected")
            status = "Fail"
           
    else:
        test.fail("Added contacts not displayed. Check it manually")

    return status