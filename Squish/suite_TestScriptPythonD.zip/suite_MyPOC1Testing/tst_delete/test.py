
import xlwt
import xlrd
'''Call the common functions to be used for this script'''
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\CommonLibraries.py"))
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\ApplicationLibraries.py"))
'''End of Calling Common Libraries'''
'''Load the shared OR'''
objectMap.load("Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\objects.map")
 
def main():
    startApplication("addressbook")
    
    addcontacts()
    source="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\delete.xls"
    destination="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\deleteResult.xls"
    deleteContact_Result(source,destination)
    Deletecontacts()
    
    
def deleteContact_Result(source,destination):

    if object.exists(":AddressBook_Contact_Container"):
        mouseClick(waitForObject(":AddressBook_Contact_Container"))
        status="Pass"
        statement="Contact is successfully selected in the addressbook"   
        resultreporting(source,1,5,statement,destination)
        push_button(":AddressBook_Button_Remove")
        if object.exists(":AddressBook_DeleteConfirmDialog_Contact"):
            test.log("Confirm Dialog Opens")
            push_button(":AddressBook_DeleteConfirmDialog_Yes")
            status = "Pass"
            statement="contact is successfully deleted"   
            resultreporting(destination,2,5,statement,destination)
                
        else:
            test.fail("Confirm Dialog Delete not displayed")
            statement="contact is not deleted"   
            resultreporting(destination,2,5,statement,destination)
                
    else:
        test.fail("Added contacts not displayed. Check it manually")
        statement="contact is not selected"   
        resultreporting(destination,1,5,statement,destination)
                
                   
    return status    