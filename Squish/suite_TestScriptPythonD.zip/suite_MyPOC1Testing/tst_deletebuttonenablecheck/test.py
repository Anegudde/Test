import xlwt
import xlrd
'''Call the common functions to be used for this script'''
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\CommonLibraries.py"))
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\ApplicationLibraries.py"))
'''End of Calling Common Libraries'''
'''Load the shared OR'''
objectMap.load("Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\objects.map")
def main():
    startApplication("addressbook")
    
    addcontacts()
    
    source="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\deletecheck.xls"
    destination="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\deletecheck_Result.xls"
    deleteButtonCheck_Result(source,destination)
    

def deleteButtonCheck_Result(source,destination):
      if object.exists(":AddressBook_Contact_Container"):
        mouseClick(waitForObject(":AddressBook_Contact_Container"))
     #   mouseClick(waitForObject(":AddressBookFile_HeaderView"))
        status="Pass"
        statement="Contact is successfully displayed in the addressbook"   
        resultreporting(source,1,5,statement,destination)
       
        value = findObject(":AddressBook_Button_Remove").enabled
        
        if value == 1:
            test.log("Remove button  enabled as expected")
            status = "Pass"
            statement="Remove button is enabled as expected"   
            resultreporting(destination,2,5,statement,destination)
            
        else:
            test.fail("Remove button not enabled as expected since the contact is  selected")
            status = "Fail"
            statement="Remove  button is not  enabled as expected"   
            resultreporting(destination,2,5,statement,destination)
            
        
      else:
        test.fail("Added contacts not displayed. Check it manually")
        status="Fail"
        statement="Contact is not successfully displayed in the addressbook"   
        resultreporting(destination,1,5,statement,destination)
        
      return status
 
  
        
 

    
   