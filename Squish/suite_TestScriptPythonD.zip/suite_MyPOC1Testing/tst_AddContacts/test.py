import xlwt
import xlrd
'''Call the common functions to be used for this script'''
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\CommonLibraries.py"))
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\ApplicationLibraries.py"))
'''End of Calling Common Libraries'''
'''Load the shared OR'''
objectMap.load("Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\objects.map")

def main():
    startApplication("addressbook")
    
  
    source="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\AddContact.xls"
    destination="C:\\Users\\MuseAdmin\\Desktop\\debi\\GE\\xcelsheetsfor results\\AddContact_Result.xls"
    addcontact_Result(source,destination)
    
def addcontact_Result(source,destination):

    for row in testData.dataset("Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\testdata\\Add_Contact.tsv"):
        Forename = testData.field(row, "ForeName")
        SurName = testData.field(row, "SurName")
        Mail = testData.field(row, "Mail")
        Phone = testData.field(row, "Phone")
    status = " "
    if status==" ":
         
        push_button(":AddressBook_Button_New")
         
        push_button(":AddressBook_Button_Add")     
        
        text_edit(":AddressBook_Textedit_Forename",Forename)
        text_edit(":AddressBook_Textedit_Surname",SurName)
        text_edit(":AddressBook_Textedit_Email",Mail)
        text_edit(":AddressBook_Textedit_Phone",Phone)
        push_button(":AddressBook_Button_OK")
        status = "Pass"
        statement = "Object forename is edited with new value of " + Forename + " successfully"
        resultreporting(source,1,5,statement,destination)
        
        statement = "Object Surname is edited with new value of " + SurName + " successfully"
        resultreporting(destination,2,5,statement,destination)
        
        statement = "Object Email is edited with new value of " + Mail + " successfully"
        resultreporting(destination,3,5,statement,destination)
        
        statement = "Object Phone is edited with new value of " + Phone + " successfully"
        resultreporting(destination,4,5,statement,destination)
        
        statement = "OK button is present"
        resultreporting(destination,5,5,statement,destination)
    else:
        test.log("Contacts already added")
        status = " "
        statement = "Object forename is alreaddy added"
        resultreporting(source,1,5,statement,destination)
        
        statement = "Object Surname is alreaddy added "
        resultreporting(destination,2,5,statement,destination)
        
        statement = "Object Email is alreaddy added"
        resultreporting(destination,3,5,statement,destination)
        
        statement = "Object Phone is alreaddy added"
        resultreporting(destination,4,5,statement,destination)
         
        statement = "OK button is not present"
        resultreporting(destination,5,5,statement,destination)
    return status