import xlwt
import xlrd
def main():
    startApplication("addressbook")
    push_button(":AddressBook_Button_New")
    addcontacts()
   