
def main():
 astring = "Hello world!"
 test.log(astring)
 lengthofString=len(astring)
 test.log(lengthofString)
 afewwords = astring.split(" ")
#test.log(afewwords)