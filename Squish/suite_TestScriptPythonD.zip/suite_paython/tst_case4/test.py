
"""Importing inbuilt python libraries"""
import string
import random
from os import urandom
from random import choice
 
"""#Main Function ---- starts"""
def main():
    lowerlimit = 3 #Declaring and assigning value to lowerlimit
    upperlimit = 5 #Declaring and assigning value to upperlimit
    Alpha = "NO"
    Numeric = "NO"
    Alphanumeric = "YES"
    Specialchar = "YES"
    SpaceBtwchar = "YES"
    NULL = "YES"
   bva_generator(lowerlimit, upperlimit, Alpha, Numeric, Alphanumeric, Specialchar, NULL, SpaceBtwchar) # Function calls
   
"""#Main Function ---- ends    """
 
"""#BVA Generator ---- Function starts"""
def bva_generator(lowerlimit, upperlimit, Alpha, Numeric, Alphanumeric, Specialchar, NULL, SpaceBtwchar):
    test.log("BVA_Random check")
    """#Input string combination"""
    chars=string.ascii_uppercase + string.ascii_lowercase
    num=string.digits
    resultant_value = string.ascii_uppercase + string.ascii_lowercase + string.digits
    """#BVA - Range string"""
    value = [lowerlimit-1, lowerlimit, lowerlimit+1, upperlimit-1, upperlimit, upperlimit+1]
    count = len(value)
   
    """#Outer loop for the range iteration"""
    for count in range(count):
        length = value[count]
        resultant_text = " "
        logic = 0
       
        """# Inner loop for each value iteration"""
        for length in range(length):
            if Alpha == "YES":
                input = "Input String : Alpha characters"
                resultant_text += random.choice(chars)
               
            if Numeric == "YES":
                input = "Input String : Numeric"
                resultant_text += random.choice(num)
               
            if Alphanumeric == "YES":
                input = "Input String : Alphanumeric"
                if logic == 0:
                    resultant_text += random.choice(chars)
                    logic = 1
                else:
                    resultant_text += random.choice(num)
                    logic = 0
                      
        test.log("The text value accepts "+input+" is " + str(resultant_text))
       
        
    """# Validation of Blank/NULL Values """      
    if NULL == "YES":
        test.log("Validate the text with passing NULL Value")
        resultant_text = " "
        test.log("The output text value is " + str(resultant_text))
       
    """# Validation of Special Character """                      
    if Specialchar == "YES":
        test.log("Validate the text with special character as input string")
       
        resultant_text = generate_word()
        test.log("The output text value is " + str(resultant_text))
                
        
    else:
        test.log("Special character not accepts here")
        #test.log(str(resultant_value))
   
    if SpaceBtwchar == "YES":
        test.log("Validate the text with spaces inbetween the character")
        resultant_text = generate_space(upperlimit)
       
    
        
        
char_set = {'small': 'abcdefghijklmnopqrstuvwxyz',
             'nums': '0123456789',
             'big': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
             'special': '^!\$%&/()=?{[]}+~#-_.:,;<>|\\'
            }             
def generate_word(length=12):
    """Function to generate a word with all combination"""
 
    word = []
 
    while len(word) < length:
        key = choice(char_set.keys())
        a_char = urandom(1)
        if a_char in char_set[key]:
            if check_prev_char(word, char_set[key]):
                continue
            else:
                word.append(a_char)
    return ''.join(word)
 
 
def check_prev_char(word, current_char_set):
    """Function to ensure that there are no consecutive
    UPPERCASE/lowercase/numbers/special-characters."""
 
    index = len(word)
    if index == 0:
        return False
    else:
        prev_char = word[index - 1]
        if prev_char in current_char_set:
            return True
        else:
            return False
 
"""Function to generate a space between the chars"""
def generate_space(upperlimit):     
    limit = upperlimit/2 
    resultant_value = string.ascii_uppercase + string.ascii_lowercase + string.digits
    value = ''
    value1 =''
    length = len(value1)
    randomtext = ""
    for c in resultant_value:
        for length in range(limit):
           
            text = random.choice(resultant_value)
            randomtext+=text
            value1+=' '+text
        break
    test.log(str(value1))  
    """ space btw chars """
    logic = 0
    if logic == 0:
        value1 = ' '+randomtext
        logic = 1
        test.log(str(value1))
        """ starts with space """
    if logic == 1:
        value1 = randomtext+' '
        #logic = 0
        test.log(str(value1))
        """ ends withs space """