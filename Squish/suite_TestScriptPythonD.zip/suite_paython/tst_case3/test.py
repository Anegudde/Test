
def breakRNA(seqRNA, *breakPoint):
    n = 0
    for i in seqRNA:
        n += 1
        for i in breakPoint:
            if i == n:
                seqRNA = seqRNA[:n]  + ' ' + seqRNA[n:]
    return seqRNA




def main():
    result = breakRNA('Saranya',0,0,0)
    
    test.log(str(result))
    result1 = breakRNA('Saranya',1,0,0)
    
    test.log(str(result1))
    result1 = breakRNA('Saranya',1,0,1)
    
    test.log(str(result1))
    result1 = breakRNA('Saranya',0,1,0)
    
    test.log(str(result1))
    result1 = breakRNA('Saranya',1,1,1)
    
    test.log(str(result1))