
function validate()
{
var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
for (var i = 0; i < document.length; i++) {
    if (iChars.indexOf(document.myForm.field1.value.charAt(i)) != -1) {
    alert ("The Field No 1 has special characters. \nSpecial Characters are not allowed");
    return false;
        }
    }
for (var i = 0; i < document.length; i++) {
    if (iChars.indexOf(document.myForm.field2.value.charAt(i)) != -1) {
    alert ("The Field No 2 has special characters. \nSpecial Characters are not allowed");
    return false;
        }
    }
} 






