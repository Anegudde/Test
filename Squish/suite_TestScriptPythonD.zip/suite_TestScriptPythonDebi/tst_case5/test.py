def main():
    startApplication("addressbook")
    table = waitForObject(":Address Book_QTableWidget")
    invokeMenuItem("File", "New")
    test.verify(table.rowCount == 0)
    data = [("Andy", "Beach", "andy.beach@nowhere.com", "555 123 6786"),
            ("Candy", "Deane", "candy.deane@nowhere.com", "555 234 8765"),
            ("Ed", "Fernleaf", "ed.fernleaf@nowhere.com", "555 876 4654")]
    for oneNameAndAddress in data:
        addNameAndAddress(oneNameAndAddress)
    test.verify(table.rowCount == len(data))
    closeWithoutSaving()