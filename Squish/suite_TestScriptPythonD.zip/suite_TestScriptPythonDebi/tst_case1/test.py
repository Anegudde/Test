
def main():
    startApplication("quickaddressbook")
    snooze(17.2)
    closeWindow(":Quick Addressbook_QQuickWindowQmlImpl")
