
def main():
    startApplication("addressbook")
    activateItem(waitForObjectItem(":Address Book_QMenuBar", "File"))
    activateItem(waitForObjectItem(":Address Book.File_QMenu", "New"))
    clickButton(waitForObject(":Address Book - Unnamed.Add_QToolButton"))
    type(waitForObject(":Forename:_LineEdit"), "y")
    mouseDrag(waitForObject(":Address Book - Add_Dialog"), 66, 44, 13, -3, 1, Qt.LeftButton)
    mouseClick(waitForObject(":Surname:_LineEdit"), 10, 4, 0, Qt.LeftButton)
    type(waitForObject(":Surname:_LineEdit"), "u")
    mouseClick(waitForObject(":Email:_LineEdit"), 14, 11, 0, Qt.LeftButton)
    type(waitForObject(":Email:_LineEdit"), "i")
    mouseClick(waitForObject(":Phone:_LineEdit"), 20, 15, 0, Qt.LeftButton)
    type(waitForObject(":Phone:_LineEdit"), "o")
    clickButton(waitForObject(":Address Book - Add.OK_QPushButton"))
    mouseClick(waitForObject(":Address Book - Unnamed.File_QTableWidget"), 286, 206, 0, Qt.LeftButton)





{buddy=':Address Book - Add.Email:_QLabel' type='LineEdit' unnamed='1' visible='1'}