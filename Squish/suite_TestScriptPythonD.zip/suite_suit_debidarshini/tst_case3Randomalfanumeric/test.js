function randomString() {
    var chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
    var string_length = 8;
    var randomstring = '';
    for (var i=0; i<string_length; i++) {
        var rnum = Math.floor(Math.random() * chars.length);
        randomstring += chars.substring(rnum,rnum+1);
      
    }
    test.log(randomstring)
}
function main(){
    randomString(randomstring); 
    
}
       // case 'AN':
        //    {
            //    if ((window.event.keyCode<48) ||(window.event.keyCode>57 && 
       //         window.event.keyCode<65) || window.event.keyCode>122 || 
   //            (window.event.keyCode>90 && window.event.keyCode<97)) 
 //               {
//                window.event.returnValue=false;
 //               alert("Please Enter Only Alpha Numeric Values");
 //               }
 //               break;
 //           }    
   // }            
//} 