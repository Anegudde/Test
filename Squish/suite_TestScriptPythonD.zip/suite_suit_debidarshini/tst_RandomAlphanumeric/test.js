function stringGen()
{
    var text = " ";var len=4;

    var charset = "abcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < len; i++ )
        text += charset.charAt(Math.floor(Math.random() * charset.length));

    return text;
}

function main()
{
    var x = stringGen();
    test.log(x);
    
}