
function stringGen(ULM,LLM)
{
    var text = " ";var len=4;
     
    var charset = "abcdefghijklmnopqrstuvwxyz0123456789";
for(var j=LLM;j<=ULM;j++)
{
    
    for( var i=0; i < len; i++ )
    {
        text += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    test.log(text);
    text="";
}
}

function main()
{
   stringGen(6,1);
}