function main(){
var x = 5;
var y = 6;
var z = x + y;
test.log("result" + z);
//document.getElementById("demo").innerHTML = z;
}