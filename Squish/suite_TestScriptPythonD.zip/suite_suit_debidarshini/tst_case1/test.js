function isValid(str) {
    //var str = "The best things in life are free";
    //var patt = new RegExp("e");
    //var res = patt.test(str); 
    
    
    var iChars = "~`!#$%^&*+=-[]\\\';,/{}|\":<>?@";
    test.log(str.length);

    for (var i = 0; i < str.length; i++) {
        
        
       if (iChars.indexOf(str.charAt(i)) != -1) {
           test.log ("File name has special characters ~`!#$%^&*+=-[]\\\';,/{}|\":<>? \nThese are not allowed\n" + str.charAt(i));
           test.log(str.charAt(i));
       }
    }
}

function main(){
    
 isValid("H*&^ello!#@");
    
}