
'''Call the common functions to be used for this script'''
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\CommonLibraries.py"))
source(findFile("scripts","Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\shared\\scripts\\ApplicationLibraries.py"))
'''End of Calling Common Libraries'''

'''Load the shared OR'''
objectMap.load("Z:\\suite_Demo_AddressBook_Shared\\suite_Demo_AddressBook_Shared\\objects.map")


def main():
  startApplication("addressbook")
  
  Result = addcontacts()
  test.log(str(Result))
 

#     

 
 