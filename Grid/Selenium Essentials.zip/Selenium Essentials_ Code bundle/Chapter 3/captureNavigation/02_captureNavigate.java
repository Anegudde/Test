package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class captureNavigate02 {
    private WebDriver driver;
    private String baseUrl;
    private static String[] links = null;
    private static int linksCount = 0;

    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void captureAndNavigate() throws Exception {

        driver.get("https://www.google.co.in");
        WebElement element = driver.findElement(By.id("_eEe"));
        List<WebElement> elements = element.findElements(By.tagName("a"));
        int sizeOfAllLinks = elements.size();
        System.out.println(sizeOfAllLinks);
        for(int i=0; i<sizeOfAllLinks ;i++)
        {
            System.out.println(elements.get(i).getAttribute("href"));
        }
        for (int index=0; index<sizeOfAllLinks; index++ ) {
            getElementWithIndex(By.tagName("a"), index).click();
            Thread.sleep(2000);
            driver.navigate().back();
        }
    }

    public WebElement getElementWithIndex(By by, int index) {
        WebElement element = driver.findElement(By.id("_eEe"));
        List<WebElement> elements = element.findElements(By.tagName("a"));
        return elements.get(index);
    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
