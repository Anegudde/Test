package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class capturelinks03 {
    private WebDriver driver;
    private String baseUrl;
    private static String[] links = null;
    private static int linksCount = 0;

    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void capturelinks() throws Exception {

        driver.get("https://www.google.co.in");
        List<WebElement> all_links_webpage = driver.findElements(By.tagName("a"));
        System.out.println("Total no of links Available: " + all_links_webpage.size());
        int k = all_links_webpage.size();
        System.out.println("List of links Available: ");
        for(int i=0;i<k;i++)
        {
            if(all_links_webpage.get(i).getAttribute("href").contains("google"))
            {
                String link = all_links_webpage.get(i).getAttribute("href");
                System.out.println(link);
            }
        }

    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
