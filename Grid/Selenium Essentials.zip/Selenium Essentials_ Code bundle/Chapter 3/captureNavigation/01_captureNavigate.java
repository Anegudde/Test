package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class captureNavigate01 {
    private WebDriver driver;
    private String baseUrl;
    private static String[] links = null;
    private static int linksCount = 0;

    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void captureAndNavigate() throws Exception {

        driver.get("https://www.google.co.in");
        List<WebElement> linksize = driver.findElements(By.tagName("a"));
        linksCount = linksize.size();
        System.out.println("Total no of links Available: "+linksCount);
        links= new String[linksCount];
        System.out.println("List of links Available: ");
        // print all the links from webpage
        for(int i=0;i<linksCount;i++)
        {
            links[i] = linksize.get(i).getAttribute("href");
        }
        // navigate to each Link on the webpage
        for(int i=0;i<linksCount;i++)
        {
            driver.navigate().to(links[i]);
            Thread.sleep(3000);
        }

    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
