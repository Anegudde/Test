package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class selectautocomplete {
    private WebDriver driver;
    private String baseUrl;


    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void autocomplete() throws Exception {

        driver.get("http://www.indiabookstore.net");
        driver.findElement(By.id("searchBox")).sendKeys("Alche");
        Thread.sleep(3000);
        List <WebElement> listItems = driver.findElements(By.cssSelector(".acResults li"));
        listItems.get(0).click();
        driver.findElement(By.id("searchButton")).click();

        Thread.sleep(2000);

    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
