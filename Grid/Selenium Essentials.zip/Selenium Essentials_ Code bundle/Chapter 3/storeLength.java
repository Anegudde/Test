package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class storeLength {
    private WebDriver driver;
    private String baseUrl;


    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void length() throws Exception {

        driver.get("https://accounts.google.com/");
        List<WebElement>Textbox =driver.findElements(By.xpath("//script[@type='text/javascript']"));
        System.out.println("Overall textboxes:"+Textbox.size());
    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
