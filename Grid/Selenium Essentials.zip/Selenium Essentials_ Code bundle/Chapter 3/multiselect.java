package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class multiselect {
    private WebDriver driver;
    private String baseUrl;


    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @Test
    public void multiselect_elements() throws Exception {

        driver.get("http://www.ryancramer.com/journal/entries/select_multiple/");

        List<WebElement> ele = driver.findElements(By.tagName("select"));
        System.out.println(ele.size());
        WebElement ele2 = ele.get(0);

        List<WebElement> ele3 = ele2.findElements(By.tagName("option"));
        System.out.println(ele3.size());

        ele2.sendKeys(Keys.CONTROL);
        ele3.get(0).click();
        ele3.get(1).click();
        ele3.get(3).click();
        ele3.get(4).click();
        ele3.get(5).click();
        Thread.sleep(2000);

    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}
