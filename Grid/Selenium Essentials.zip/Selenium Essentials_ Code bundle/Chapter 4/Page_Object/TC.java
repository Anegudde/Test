package pop;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC {
    private WebDriver driver;
    public ASSERT Task;

    @BeforeTest
    public void setUp() throws Exception {
        System.out.println("Instantiating Chrome Driver...");
        driver = new ChromeDriver();
    }

    @Test
    public void Test01() throws Exception {
        URL url = new URL(driver);
        url.geturl();
    }

    @Test
    public void Test02() throws Exception {
        Task = new ASSERT(driver);
        Task.search();
    }

    @Test
    public void Test03() throws Exception {
        Task = new ASSERT(driver);
        Task.assertTitle();
    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }
}

