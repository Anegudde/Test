package pop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ASSERT {

    public WebDriver driver;
    private final Wait<WebDriver> wait;

    public ASSERT(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, 10);
        //driver.get("https://seleniumworks.com");
    }

    public void search() throws Exception{
        //  search google
        wait.until(ExpectedConditions.presenceOfElementLocated(By.name("q")));
        driver.findElement(By.name("q")).sendKeys("Prashanth Sams");
        driver.findElement(By.name("q")).submit();
        System.out.println("Google Search - SUCCESS!!");
        Thread.sleep(4000);
    }

    public void assertTitle() throws Exception{
        //  assert google search
        Boolean b = driver.getTitle().contains("Prashanth Sams");
        System.out.println(b);
    }
}
