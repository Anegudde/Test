package pop;

import org.openqa.selenium.WebDriver;

public class URL{
    public WebDriver driver;
    private String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();

    public URL(WebDriver driver) {
        this.driver = driver;
        driver.get("http://www.google.co.in");
    }

    public ASSERT geturl() {
        System.out.println("Opened URL successfully");
        return new ASSERT(driver);
    }
}
