package Selenium_essentials;

import org.openqa.selenium.*;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

import java.io.File;

/**
 * Created by prashanth_sams on 18/09/14.
 */
public class Listeners extends AbstractWebDriverEventListener {
    // public class Listeners implements WebDriverEventListener {
    private By finalFindBy;
    private WebElement lastElement;
    private String actualValue;
    private String modifiedValue;

    /** URL NAVIGATION | navigate(), get() **/

    // Prints the URL before Navigating to specific URL
    @Override
    public void beforeNavigateTo(String url, WebDriver driver) {
        System.out.println("Before Navigating To : " + url + ", my url was: " + driver.getCurrentUrl());
    }

    // Prints the current URL after Navigating to specific URL
    @Override
    public void afterNavigateTo(String url, WebDriver driver) {
        System.out.println("After Navigating To: " + url + ", my url is: " + driver.getCurrentUrl());
    }

    // Prints the URL before Navigating back "navigate().back()"
    @Override
    public void beforeNavigateBack(WebDriver driver) {
        System.out.println("Before Navigating Back. I was at " + driver.getCurrentUrl());
    }

    // Prints the current URL after Navigating back from the previous URL
    @Override
    public void afterNavigateBack(WebDriver driver) {
        System.out.println("After Navigating Back. I'm at " + driver.getCurrentUrl());
    }

    // Prints the URL before Navigating forward "navigate().forward()"
    @Override
    public void beforeNavigateForward(WebDriver driver) {
        System.out.println("Before Navigating Forward. I was at " + driver.getCurrentUrl());
    }

    // Prints the current URL after Navigating forward "navigate().forward()"
    @Override
    public void afterNavigateForward(WebDriver driver) {
        System.out.println("After Navigating Forward. I'm at " + driver.getCurrentUrl());
    }

    /** FINDING ELEMENTS | findElement(), findElements() **/

    // Called before finding Element(s)
    @Override
    public void beforeFindBy(By by, WebElement element, WebDriver driver) {
        finalFindBy = by;
        System.out.println("Trying to find: '" + finalFindBy + "'.");
        System.out.println("Trying to find: " + by.toString()); // This is optional and an alternate way
    }

    // Called after finding Element(s)
    @Override
    public void afterFindBy(By by, WebElement element, WebDriver driver) {
        finalFindBy = by;
        System.out.println("Found: '" + finalFindBy + "'.");
        System.out.println("Found: " + by.toString() + "'."); // This is optional and an alternate way
    }

    /** CLICK | click() **/

    // Called before clicking an Element
    @Override
    public void beforeClickOn(WebElement element, WebDriver driver) {
        System.out.println("Trying to click: '" + element + "'");

        // Highlight Elements before clicking
        for (int i = 0; i < 1; i++) {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript(
                    "arguments[0].setAttribute('style', arguments[1]);",
                    element, "color: black; border: 3px solid black;");
        }
    }

    // Called after clicking an Element
    @Override
    public void afterClickOn(WebElement element, WebDriver driver) {
        System.out.println("Clicked Element with: '" + element + "'");
    }

    /** CHANGING VALUES | clear(), sendKeys() **/

    // Before modifying values
    @Override
    public void beforeChangeValueOf(WebElement element, WebDriver driver) {
        actualValue = element.getText();

        if (actualValue.isEmpty()) {
            actualValue = element.getAttribute("value");
        }
        System.out.println("The existing value is: " + actualValue);
    }

    // After modifying values
    @Override
    public void afterChangeValueOf(WebElement element, WebDriver driver) {
        modifiedValue = "";
        try {
            modifiedValue = element.getText();
        } catch (StaleElementReferenceException e) {
            System.out.println("StaleElementReferenceException is thrown");
            return;
        }

        if (modifiedValue.isEmpty()) {
            modifiedValue = element.getAttribute("value");
        }

        System.out.println("The value changed from '" + actualValue + "' to '" + modifiedValue + "'");
    }

    /** SCRIPT | beforeScript(), afterScript()**/

    // Called before executing RemoteWebDriver.executeScript(java.lang.String, java.lang.Object[])
    @Override
    public void beforeScript(String script, WebDriver driver) {
        System.out.println("JavaScript is about to execute");
    }

    // Called after executing RemoteWebDriver.executeScript(java.lang.String, java.lang.Object[])
    @Override
    public void afterScript(String script, WebDriver driver) {
        System.out.println("JavaScript is Executed");
    }

    /** ON EXCEPTION | capture screenshots on test failure **/

    // Takes screenshot on any Exception thrown during test execution
    @Override
    public void onException(Throwable throwable, WebDriver webdriver) {
        System.out.println("Caught Exception");
        File scrFile = ((TakesScreenshot) webdriver)
                .getScreenshotAs(OutputType.FILE);
        try {
            org.apache.commons.io.FileUtils.copyFile(scrFile, new File(
                    "/Users/prashanth_sams/Desktop/Testfailure.jpeg"));
        } catch (Exception e) {
            System.out.println("Unable to Save");
        }
    }
}
