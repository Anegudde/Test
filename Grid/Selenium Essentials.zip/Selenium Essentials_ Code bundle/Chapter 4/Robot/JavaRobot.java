package pack;

/**
 * Created by prashanth_sams on 09/12/14.
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.lang.reflect.Field;

public class JavaRobot {
    private WebDriver driver;
    private String baseUrl;

    @Test
    public void Test01() throws Exception {
        driver = new ChromeDriver();
        driver.get("https://www.google.com");

        Robot r = new Robot();
        driver.findElement(By.name("q")).click();
        Thread.sleep(4000);
        typeKeys("Prashanth Sams", r);
    }

    public static void typeKeys(String str, Robot r) {
        for (int i = 0; i < str.length(); i++) {
            typeCharacter(r, "" + str.charAt(i));
        }
    }

    public static void typeCharacter(Robot robot, String letter) {

        try {
            boolean upperCase = Character.isUpperCase(letter.charAt(0));
            String variableName = "VK_" + letter.toUpperCase();
            Class c = KeyEvent.class;
            Field field = c.getField(variableName);
            int keyCode = field.getInt(null);
            robot.delay(1000);

            if (upperCase) robot.keyPress(KeyEvent.VK_SHIFT);

            robot.keyPress(keyCode);
            robot.keyRelease(keyCode);

            if (upperCase) robot.keyRelease(KeyEvent.VK_SHIFT);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}

