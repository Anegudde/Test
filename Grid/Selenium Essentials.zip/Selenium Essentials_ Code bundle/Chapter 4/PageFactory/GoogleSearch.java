package page;

/**
 * Created by prashanth_sams on 18/11/14.
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleSearch {

    private WebElement q; // Here's the Element
    public WebDriver driver;

    public GoogleSearch(WebDriver driver) {
        this.driver = driver;
        driver.get("http://www.google.com/");
    }

    public void searchFor(String text) {
        q.sendKeys(text);
        q.submit();
    }
}
