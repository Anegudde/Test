package page;

/**
 * Created by prashanth_sams on 18/11/14.
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GoogleTest {
    private WebDriver driver;

    @BeforeTest
    public void setUp() throws Exception {
        driver = new ChromeDriver();
    }

    @Test
    public void Test01() throws Exception{
        GoogleSearch page = PageFactory.initElements(driver, GoogleSearch.class);
        page.searchFor("Prashanth Sams");
    }

    @AfterTest
    public void Teardown() throws Exception{
        driver.quit();
    }
}

