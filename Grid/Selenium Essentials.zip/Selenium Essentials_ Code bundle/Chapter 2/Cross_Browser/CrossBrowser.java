package pack;

import com.opera.core.systems.OperaDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.net.MalformedURLException;

/**
 * Created by prashanth_sams on 11/12/14.
 */

public class CrossBrowser {

    private WebDriver driver;
    private String baseUrl;
    private boolean acceptNextAlert = true;
    private StringBuffer verificationErrors = new StringBuffer();

    @BeforeTest
    @Parameters({"browser"})
    public void setUp(String browser) throws MalformedURLException {
        if (browser.equalsIgnoreCase("Firefox")) {
            System.out.println("Running Firefox");
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("chrome")) {
            System.out.println("Running Chrome");
//            System.setProperty("webdriver.chrome.driver","C:\\chromedriver.exe");
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("InternetExplorer")) {
            System.out.println("Running Internet Explorer");
            System.setProperty("webdriver.ie.driver", "C:\\IEDriverServer.exe");
            DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
            dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);  //If IE fail to work, please remove this line and remove enable protected mode for all the 4 zones from Internet options
            driver = new InternetExplorerDriver(dc);
        } else if (browser.equalsIgnoreCase("safari")) {
            System.out.println("Running Safari");
            driver = new SafariDriver();
        } else if (browser.equalsIgnoreCase("opera")) {
            System.out.println("Running Opera");
            // driver = new OperaDriver();       --Use this if the location is set properly | see note #2 below--
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("opera.binary", "C://Program Files (x86)//Opera//opera.exe");
            capabilities.setCapability("opera.log.level", "CONFIG");
            driver = new OperaDriver(capabilities);
        }
    }

    @Test
    public void GoogleTest() throws Exception {
        driver.get("http://www.google.com/");
        System.out.println("Page title is: " + driver.getTitle());
        Assert.assertEquals("Google", driver.getTitle());
        WebElement element = driver.findElement(By.name("q"));
        element.sendKeys("Selenium Essentials");
        element.submit();
    }

    @AfterTest
    public void tearDown() throws Exception {
        driver.quit();
    }

}