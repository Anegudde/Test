package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class CSVDriven {
	private WebDriver driver;
	private String baseUrl;

	String path = "/Users/prashanth_sams/Desktop/data.csv";

	@BeforeTest
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		baseUrl = "https://www.google.com";
	}

	@Test
	public void Test01() throws Exception {
		driver.get(baseUrl + "/");

		FileWriter writer = new FileWriter("/Users/prashanth_sams/Desktop/output.csv");
		writer.append("ColumnHeader1");
		writer.append(',');
		writer.append("ColumnHeader2");
		writer.append('\n');

		File file = new File(path);
		BufferedReader IN = new BufferedReader(new FileReader(file));
		String line = null;
		while ((line = IN.readLine()) != null) {
			String[] data = line.split(",");

			driver.findElement(By.name("q")).sendKeys(data[0]);
			driver.findElement(By.name("q")).submit();
			Thread.sleep(2000);
			String element1 = driver.getTitle();
			driver.findElement(By.name("q")).clear();

			driver.findElement(By.name("q")).sendKeys(data[1]);
			driver.findElement(By.name("q")).submit();
			Thread.sleep(2000);
			String element2 = driver.getTitle();

			writer.append(element1);
			writer.append(',');
			writer.append(element2);
			writer.append('\n');
			writer.flush();
		}
		try {
			IN.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
    @AfterClass
    public void AfterClass() {
        driver.quit();
    }
}


