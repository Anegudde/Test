package pack;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class GoogleTest {
    WebDriver driver;
    private String baseUrl;

    @BeforeClass
    public void BeforeClass() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        baseUrl = "http://www.google.co.in";
    }

    @Test
    public void Test01() {
        Execute();
    }

    public void Execute() {

        BufferedReader in = null;
        InputStreamReader inputStream = null;
        try {

            inputStream = new InputStreamReader(new FileInputStream("/Users/prashanth_sams/Desktop/"
                    + File.separator + "data.txt"));
            in = new BufferedReader(inputStream);
            String line = null;
            String actualvalue = "";
            String expectedvalue = "";
            while ((line = in.readLine()) != null) {
                String[] data = line.split(", ");
                if (data.length >= 1) {
                    actualvalue = data[0];
                    expectedvalue = data[1];
                    System.out.println("Actual : " + actualvalue);
                    System.out.println("Expected : " + expectedvalue);
                    // for (int i = 0; i < 10; i++) { // same action multiple times
                    // Your CODE here
                    driver.get(baseUrl + "/");
                    driver.findElement(By.name("q")).sendKeys(actualvalue);
                    driver.findElement(By.name("q")).sendKeys(Keys.RETURN);
                    boolean b = driver.getPageSource().contains(expectedvalue);
                    Assert.assertTrue(b);
                    // }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @AfterClass
    public void AfterClass() {
        driver.quit();
    }
}

