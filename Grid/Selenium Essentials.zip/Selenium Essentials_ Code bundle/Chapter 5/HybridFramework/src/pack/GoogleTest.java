package pack;

import pack.drivers.loadDriver;
import pack.ObjRep.ObjectRepository;
import org.testng.annotations.Test;

public class GoogleTest {

    //Positive Use_case
    @Test(enabled = true, priority = 2)
    public void TC_01() throws InterruptedException {
        loadDriver.Chrome();
        loadDriver.URL();
        loadDriver.WaitForPageLoad();
        loadDriver.waitForID(ObjectRepository.searchField);
        loadDriver.clearID(ObjectRepository.searchField);
        loadDriver.insertText(ObjectRepository.searchField, ObjectRepository.searchText1);
        loadDriver.submit(ObjectRepository.submitButton);
        loadDriver.sleeper(3000);
        loadDriver.assertPageTitle();
        loadDriver.exit();
    }

    //Negative Use_case
    @Test (enabled = true, priority = 1)
    public void TC_02() throws InterruptedException {
        loadDriver.Chrome();
        loadDriver.URL();
        loadDriver.WaitForPageLoad();
        loadDriver.waitForID(ObjectRepository.searchField);
        loadDriver.clearID(ObjectRepository.searchField);
        loadDriver.insertText(ObjectRepository.searchField,
                ObjectRepository.searchText2);
        loadDriver.submit(ObjectRepository.submitButton);
        loadDriver.sleeper(3000);
        loadDriver.assertPageTitle();
        loadDriver.exit();
    }
}
