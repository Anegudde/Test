package pack.ObjRep;

public class ObjectRepository {
    public static final String URL = "https://www.google.com/";
    public static final String searchField = "lst-ib";
    public static final String searchText1 = "Prashanth Sams";
    public static final String searchText2 = "Selenium Essentials";
    public static final String submitButton = "sblsbb";
    public static final String title = "Prashanth Sams - Google Search";
}

