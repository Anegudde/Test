package com.gaurang;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Created by Gaurang Shah on 25/04/15.
 */

@RunWith(Cucumber.class)
@CucumberOptions(plugin={"pretty", "html:target/cucumber-html-report"})
public class RunAllTests {

}
