package tut.mongodb;

import com.mongodb.BasicDBObject;

public class Comments extends BasicDBObject  {	
	
	private static final long serialVersionUID = 2L;
	
	public String user;
    public String comment;
    
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public Comments(String user, String comment){
		super.put("user", user);
		super.put("comment", comment);
	}
}
