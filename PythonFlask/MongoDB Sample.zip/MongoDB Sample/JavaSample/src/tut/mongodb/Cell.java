package tut.mongodb;

public class Cell {
	public int _id;
	public String Product;
	public int Price;
	public String Make;	
	public boolean InStock;
	public String[] Tag;
	public Spec spec;
	public Comments[] comments;
	
	public int get_id() {
		return _id;
	}
	public void set_id(int _id) {
		this._id = _id;
	}
	public String getProduct() {
		return Product;
	}
	public void setProduct(String product) {
		Product = product;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	public String getMake() {
		return Make;
	}
	public void setMake(String make) {
		Make = make;
	}
	public boolean isInStock() {
		return InStock;
	}
	public void setInStock(boolean inStock) {
		InStock = inStock;
	}
	public String[] getTag() {
		return Tag;
	}
	public void setTag(String[] tag) {
		Tag = tag;
	}
	public Spec getSpec() {
		return spec;
	}
	public void setSpec(Spec spec) {
		this.spec = spec;
	}
	public Comments[] getComments() {
		return comments;
	}
	public void setComments(Comments[] comments) {
		this.comments = comments;
	}
	
	
	
}
