package tut.mongodb;

import com.mongodb.BasicDBObject;

public class Spec extends BasicDBObject  {
	
	private static final long serialVersionUID = 1L;
	
	public double screen;
	public double thickness;
	
	public double getScreen() {
		return screen;
	}
	public void setScreen(double screen) {
		this.screen = screen;
	}
	public double getThickness() {
		return thickness;
	}
	public void setThickness(double thickness) {
		this.thickness = thickness;
	}
	
	public Spec(double screen, double thickness){				
		super.put("screen", new Double(screen));
		super.put("thickness", new Double(thickness));
	}
}
