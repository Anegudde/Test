package tut.mongodb;

import java.net.UnknownHostException; 
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import tut.mongodb.*;

public class Sample2 {
	
	public static void main(String[] args) throws UnknownHostException {		
	      
		MongoClient mongo = new MongoClient("localhost");
		DB db = mongo.getDB("shopping2");
		
		DBCollection collection = db.getCollection("mobiles");
		addMobile(collection);
		//readMobile(collection, "iphone6");
		readMobile(collection, "Lumia6000");
	}
	
	private static void readMobile(DBCollection collection, String product){
		DBObject query = BasicDBObjectBuilder.start().add("Product", product).get();        
		DBCursor cursor = collection.find(query);        
		while(cursor.hasNext()){            
			System.out.println(cursor.next());        
		}
	}
	
	private static void addMobile(DBCollection collection) { 
		
		Cell cell = new Cell();
		cell.Product = "Lumia6000";
		cell.Price = 10000;
		cell.Make = "Microsoft";		
		cell.InStock = true;
		cell.Tag = new String[] { "mobile","nokia" };		
		cell.spec = new Spec(3, 12);
		cell.comments = new Comments[] { new Comments("user3", "Good...") };
		
		DBObject mobileBBObj = createMobileDBObject(cell);
		
		WriteResult result = collection.insert(mobileBBObj);
		 		
	}
	
	private static DBObject createMobileDBObject(Cell cell) {        
		BasicDBObjectBuilder docBuilder = BasicDBObjectBuilder.start();		    
		docBuilder.append("Product", cell.getProduct()); 
		docBuilder.append("Price", cell.getPrice());   
		docBuilder.append("Make", cell.getMake());		     
		docBuilder.append("InStock", cell.isInStock()); 
		docBuilder.append("Tag", cell.getTag());
		docBuilder.append("Spec", cell.getSpec());
		docBuilder.append("Comments", cell.getComments());
		return docBuilder.get();    
	}
	
	
}
