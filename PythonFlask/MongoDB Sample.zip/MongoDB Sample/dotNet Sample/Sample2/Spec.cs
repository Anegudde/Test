﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sample2
{
    public class Spec
    {
        public double screen { get; set; }
        public double thickness { get; set; }       

        public Spec(double screen, double thickness)
        {
            this.screen = screen;
            this.thickness = thickness;
        }
    }
}
