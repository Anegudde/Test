﻿using System;
using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;

namespace Sample2
{
    public class Cell
    {
        public Cell() 
        { 
            
        }

        [BsonId]
        public ObjectId _id { get; set; }

        [BsonElement("Product")]       
        public string Product { get; set; }

        [BsonElement("Price")]       
        public int Price { get; set; }

        [BsonElement("Make")]       
        public string Make { get; set; }

        [BsonElement("InStock")]       
        public bool InStock { get; set; }

        [BsonElement("Tag")]       
        public string[] Tag { get; set; }

        [BsonElement("Spec")]       
        public Spec Spec { get; set; }

        [BsonElement("Comments")]      
        public Comments[] Comments { get; set; }
    }
}
