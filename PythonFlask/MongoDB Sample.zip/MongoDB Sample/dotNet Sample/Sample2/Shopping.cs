﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using MongoDB.Driver.GridFS;
using MongoDB.Driver.Linq;

namespace Sample2
{
    class Shopping
    {
        static void Main(string[] args)
        {
            const string connectionString = "mongodb://localhost";
            // Create a MongoClient object by using the connection string
            var client = new MongoClient(connectionString);

            //Use the MongoClient to access the server
            MongoServer server = client.GetServer();

            // Use the server to access the 'test' database
            MongoDatabase database = server.GetDatabase("shopping2");

            addMobile(database);
            //updateInStock(database, "Lumia7300", false);
            //queryMobile(database, "iphone6");
            queryMobile(database, "Lumia7300");
            Console.ReadKey();
        }

        private static void addMobile(MongoDatabase database)
        {
            var mobiles = database.GetCollection<Cell>("mobiles");
            var mobile = new Cell()
            {
                Product = "Lumia7300",               
                Price = 15000,
                Make = "Microsoft",
                InStock = true,
                Tag = new string[] { "mobile", "Nokia" },
                Spec = new Spec( 4, 9),
                Comments = new Comments[] { new Comments("user1", "Ok Phone"), new Comments("user2", "Cheap..") }
            };
            mobiles.Insert(mobile);
            Console.WriteLine("Added the mobile: Lumia7300");
        }

        private static void queryMobile(MongoDatabase database, string product)
        {
            var mobiles = database.GetCollection<Cell>("mobiles");
            var mobileQuery = Query<Cell>.EQ(g => g.Product, product);
            var mobile = mobiles.FindOne(mobileQuery);
            Console.WriteLine("Product: {0}, Make: {1}, Price: {2}, InStock: {3}, Screen: {4}", mobile.Product, mobile.Make,
                mobile.Price, mobile.InStock, mobile.Spec.screen);

        }

        private static void updateInStock(MongoDatabase database, string product, bool inStock)
        {
            var mobiles = database.GetCollection<Cell>("mobiles");
            var mobileQuery = Query<Cell>.EQ(g => g.Product, product);
            var set = Update<Cell>.Set(p => p.InStock, inStock);
            mobiles.Update(mobileQuery, set);
        }
    }
}
