﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sample2
{
    public class Comments
    {
        public string user;
        public string comment;

        public Comments(string user, string comment)
        {
            this.user = user;
            this.comment = comment;
        }
    }
}
