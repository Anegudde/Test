describe( "Sample Javascript Function Tests", function () {
  it("Hello World?", function () {
	  expect(helloWorld()).toEqual("Hello World");
  });

  it("Exit World?", function () {
	  expect(ExitWorld()).toContain("World");
  });
});

describe('Addition operator', function () {
    it('adds two numbers together : should be equal to 7', function () {
        expect(1 + 2).toEqual(3);
    });
});
/*
describe ( "Switch Case#1", function () {
  it("Switch Case Logic?", function () {
	  expect(switchValues(1)).toContain("History");
  }); 
});
*/
