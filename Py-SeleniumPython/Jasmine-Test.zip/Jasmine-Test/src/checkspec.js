/* Java Script Function
 @Name: 
 @param: None
 @param: string
*/
function helloWorld(){
	return "Hello World";
}

/* Java Script Function
 @Name: 
 @param: None
 @param: string
*/
function ExitWorld(){
	return "World is not Enough";
}
/* Java Script Function 
 @Name: 
 @param: None
 @param: None
function switchValues(var val) {
if( val == 1 ){
   return "History";
}else if( val == 2 ){
   return "Maths";
}else if( val == 3 ){
   return "Economics"
}else{
  return "Boring";
}
*/
