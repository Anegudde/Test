package com.cucumber.Runner;

import static org.testng.AssertJUnit.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cucumber.api.java.en.*;

public class SearchSteps {
	private WebDriver driver;
	
	
	@Given("^I am already logged in$")
	public void I_am_already_logged_in() {
//	   System.setProperty("webdriver.chrome.driver", "D:\\Work\\Drivers\\chromedriver.exe");
//	   driver = new ChromeDriver();
	   System.setProperty("webdriver.ie.driver", "D:\\Work\\Drivers\\IEDriverServer.exe");
	   driver = new InternetExplorerDriver();		
	   driver.get("http://demo.testlink.org");	   
	}
	
	@When("^I enter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void I_enter_as(String arg1, String arg2)
	{	
	   driver.findElement(By.name(arg1)).sendKeys(arg2);
	   
	}
/*
	@When("^I enter \"([^\"]*)\" with \"([^\"]*)\"$")
	public void I_enter_with(String arg1, String arg2)   {
		 driver.findElement(By.name("tl_password")).sendKeys("admin");
		 
	}*/
	
	@When("^I click the \"([^\"]*)\" button$")
	public void I_click_the_button(String arg1) throws Throwable {
	    driver.findElement(By.name(arg1)).click();
	}

	@Then("^I verify i am in home page$")
	public void I_verify_iam_in_home_page()  {
		String s = "TestLink 1.9.13 [DEV] (Stormbringer) 20141226";
		assertEquals(s, driver.getTitle());		
	    System.out.println("checking");
	}



}
