package com.cucumber.scenario;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cucumber.api.java.en.*;

public class ScenarioSteps {
	

@Given("^there are (\\d+) cucumbers$")
public void there_are_cucumbers(int arg1) throws Throwable {
    // Express the Regexp above with the code you wish you had
    //throw new PendingException();
}

@When("^I eat (\\d+) cucumbers$")
public void I_eat_cucumbers(int arg1) throws Throwable {
    // Express the Regexp above with the code you wish you had
    //throw new PendingException();
}

@Then("^I should have (\\d+) cucumbers$")
public void I_should_have_cucumbers(int arg1) throws Throwable {
    // Express the Regexp above with the code you wish you had
    //throw new PendingException();
}

private Map<String, Table> tablelist;
@Given("^there are <start> and <eat> Onions$")
public void there_are_start_and_eat_Onions(List<Table> tables) throws Throwable {
    // Express the Regexp above with the code you wish you had
    // For automatic conversion, change DataTable to List<YourType>
	// http://blog.czeczotka.com/2014/08/17/writing-cucumber-jvm-step-definitions/
	tablelist = new HashMap<String, Table>();

	 for (Table table : tables) {
         String person = table.getPerson();
         tablelist.put(person, table);
     }
    //throw new PendingException();
}



@When("^I manage Onions$")
public void I_manage_Onions() throws Throwable {
    // Express the Regexp above with the code you wish you had
    //throw new PendingException();
}

@Then("^I should have No Onions$")
public void I_should_have_No_Onions() throws Throwable {
    // Express the Regexp above with the code you wish you had
    //throw new PendingException();
}
	
	
}