package com.cucumber.scenario;

public class Table {
    private String person;
    private Integer order;
    private Integer details;

    public Table(String person, Integer order, Integer details) {
        this.person = person;
        this.order = order;
        this.details = details;
    }

    public String getPerson() {
        return person;
    }

    public Integer getOrder() {
        return order;
    }

    public Integer getDetails() {
        return details;
    }
}