package com.cucumber.price;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\com\\cucumber\\features\\pricelist.feature",
		//format ={"pretty"},
		//strict = false,
		format = {"pretty"},
		//glue={"src\\com\\cucumber\\Defs"},
		dryRun =false
		//tags = {"@Runme"}
		)

public class PriceListTest {

}