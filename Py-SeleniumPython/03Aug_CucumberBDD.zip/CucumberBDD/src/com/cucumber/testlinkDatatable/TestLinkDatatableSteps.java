package com.cucumber.testlinkDatatable;
//http://eloraparija.com/how-to-create-datatable-using-cucumber-feature-file-in-java/
import static org.testng.AssertJUnit.assertEquals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.internal.compiler.ast.ExplicitConstructorCall;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.*;



public class TestLinkDatatableSteps {

	private WebDriver driver;
	String s = "TestLink 1.9.13 [DEV] (Stormbringer) 20141226";
	
	@Before
	public void setupIEDriver()
	{		

	}
	
	@Given("^i login to \"([^\"]*)\"$")
	public void i_login_to(String arg1) throws Throwable {
	    // Express the Regexp above with the code you wish you had
//	    throw new PendingException(); 
		System.setProperty("webdriver.ie.driver", "D:\\Work\\Drivers\\IEDriverServer.exe");
	   	driver = new InternetExplorerDriver();	
		driver.get(arg1);	   
	   
	}
	@When("^i enter \"([^\"]*)\" as <username>$")
	public void i_enter_as_username(String arg1, List<String> Username) throws Throwable 
	{
		for (String data : Username) 
		{
			driver.findElement(By.name(arg1)).clear();
			driver.findElement(By.name(arg1)).sendKeys(data);
			
		}						   
	}			

	
	@When("^i enter \"([^\"]*)\" as <Password>$")
	public void i_enter_as_Password(String arg1, List<String> UserPwd) throws Throwable {
	    // Express the Regexp above with the code you wish you had
	    // For automatic conversion, change DataTable to List<YourType>

		for (String data : UserPwd) 
		{
			driver.findElement(By.name(arg1)).clear();
			driver.findElement(By.name(arg1)).sendKeys(data);
		}		
	}

	@When("^I click the login with admin and admin clicking the \"([^\"]*)\" button$")
	public void I_click_the_login_with_admin_and_admin_clicking_the_button(String arg1) throws Throwable {
	    // Express the Regexp above with the code you wish you had
//	    throw new PendingException();
		driver.findElement(By.name(arg1)).click();
	}
	
	@When("^I click the Selection listed here to switch through the Projects$")
	public void I_click_the_Selection_listed_here_to_switch_through_the_Projects(DataTable arg1)throws Throwable  
	{
		List<Map<String,String>> data=arg1.asMaps();
		//System.out.println("Project " +data.get(0).get("testproject")+" with options "+data.get(0).get("ProjectName"));
		int it =0;
		driver.switchTo().frame("titlebar");
		while (it < data.size())
			{	
			
//			Boolean value =driver.findElement(By.xpath("/html/body/div[3]/div/form/select")).isDisplayed();
//			System.out.println(value);
//			System.out.println("#########");
			//Select select = new Select(driver.findElement(By.xpath("/html/body/div[3]/div/form/select")));
			Thread.sleep(2000);
			driver.findElement(By.xpath("/html/body/div[3]/div/form/select")).sendKeys(data.get(it).get("ProjectName"));
			Thread.sleep(10000);
			//select.selectByIndex(it);//(data.get(it).get("ProjectName"));	
			//System.out.println(data.get(it).get("ProjectName"));
			it++;
			}		
	}
	
	@Then("^i should login to testlink successfully$")
	public void i_should_login_to_testlink_successfully() throws Throwable {
	    // Express the Regexp above with the code you wish you had		
		assertEquals(s, driver.getTitle());		
	    System.out.println("checking");
	    
	}
	
	@Then("^Close all Browsers$")
	public void Close_all_Browsers() throws Throwable
	{
		System.out.println("Exiting");
		driver.close();				
	}
	

	
}