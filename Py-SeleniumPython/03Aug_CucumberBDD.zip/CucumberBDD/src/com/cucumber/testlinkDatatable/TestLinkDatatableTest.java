package com.cucumber.testlinkDatatable;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\com\\cucumber\\features\\tabletestLinkDatatable.feature",
		//format ={"pretty"},
		//strict = false,		
		format = {"html:target", "pretty"},		
		//glue={"src\\com\\cucumber\\Defs"},
		dryRun =false,
		tags = {"@TestMe"}
		)

public class TestLinkDatatableTest {

}