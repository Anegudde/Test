package com.cucumber.Runner;

import org.junit.runner.RunWith;
import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src\\com\\cucumber\\features\\Search.feature",
		//format ={"pretty"},
		//strict = false,
		format = {"json:test-output/cucumber.json", "pretty"},
		//glue={"src\\com\\cucumber\\Defs"},
		dryRun =false
		//tags = {"@Runme"}
		)

public class SearchTest {

}
